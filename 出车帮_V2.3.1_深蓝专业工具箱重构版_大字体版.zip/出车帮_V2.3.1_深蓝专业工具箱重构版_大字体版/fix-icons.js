const fs = require('fs');
const path = 'C:/Users/mfkud/Documents/New project/司机申诉助手/utils/templates.js';
let content = fs.readFileSync(path, 'utf8');

// Fix the corrupted icon paths - replace scene_.svg with scene_XX.svg based on scene id
let idx = 1;
content = content.replace(/icon: '\/images\/scene_\.svg',/g, () => {
  const num = String(idx).padStart(2, '0');
  idx++;
  return `icon: '/images/scene_${num}.svg',`;
});

fs.writeFileSync(path, content);
console.log('Fixed icon paths');

// Verify
const verify = fs.readFileSync(path, 'utf8');
const matches = verify.match(/icon:.*/g);
console.log(matches.slice(0, 12).join('\n'));
