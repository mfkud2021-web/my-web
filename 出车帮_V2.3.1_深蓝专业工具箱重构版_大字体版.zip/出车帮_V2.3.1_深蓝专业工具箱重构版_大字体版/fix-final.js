const fs = require('fs');
const path = 'C:/Users/mfkud/Documents/New project/司机申诉助手/utils/templates.js';
let content = fs.readFileSync(path, 'utf8');

// Fix pattern: "undefined: '2026-06'" -> proper icon + updated
let idx = 1;
content = content.replace(/undefined: '2026-06',/g, () => {
  const num = String(idx).padStart(2, '0');
  idx++;
  return `icon: '/images/scene_${num}.svg',\n    updated: '2026-06',`;
});

// Fix last one: "undefined\n    tags:" -> icon + updated
const lastNum = String(idx).padStart(2, '0');
content = content.replace(/undefined\n    tags:/, `icon: '/images/scene_${lastNum}.svg',\n    updated: '2026-06',\n    tags:`);

fs.writeFileSync(path, content);
console.log('Fixed all icon paths');

// Verify
const verify = fs.readFileSync(path, 'utf8');
const matches = verify.match(/icon:.*/g);
if (matches) {
  console.log('Found ' + matches.length + ' icon fields');
  console.log(matches.slice(0, 12).join('\n'));
}
