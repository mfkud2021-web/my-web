App({
  onLaunch() {
    ['favorites', 'history'].forEach(key => {
      try {
        if (!Array.isArray(wx.getStorageSync(key))) wx.setStorageSync(key, []);
      } catch (e) { wx.setStorageSync(key, []); }
    });
    ['appeal_drafts', 'emergency_progress', 'vehicle_profile'].forEach(key => {
      try {
        const value = wx.getStorageSync(key);
        if (!value || typeof value !== 'object' || Array.isArray(value)) wx.setStorageSync(key, {});
      } catch (e) { wx.setStorageSync(key, {}); }
    });
  }
})
