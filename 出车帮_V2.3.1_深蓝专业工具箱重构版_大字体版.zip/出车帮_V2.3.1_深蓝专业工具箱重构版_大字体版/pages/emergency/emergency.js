const { getEmergencyProgress, saveEmergencyProgress, clearEmergencyProgress } = require('../../utils/storage');

const OPTIONS = [
  { id: 'general', title: '通用快速取证', iconPath: '/images/knowledge_active.png', sceneId: null, evidence: ['确认人身和道路安全', '保存订单详情', '记录时间与定位', '保存平台通话记录', '保存聊天记录', '拍摄现场照片或视频', '联系平台客服', '记录关键时间点'] },
  { id: 'late', title: '乘客迟到或失联', iconPath: '/images/scene_01.png', sceneId: 1, evidence: ['确认停靠位置安全', '保存订单与到达时间', '保存定位与等待时长', '保存通话和聊天记录', '联系平台客服'] },
  { id: 'cancel', title: '乘客取消订单', iconPath: '/images/scene_02.png', sceneId: 2, evidence: ['保存订单取消页面', '保存接单后行驶轨迹', '保存通话或聊天记录', '记录取消时间', '联系平台客服'] },
  { id: 'drunk', title: '醉酒或情绪异常', iconPath: '/images/scene_09.png', sceneId: 9, safety: true, evidence: ['将车辆停在安全位置', '避免争执并保持距离', '保存订单与沟通记录', '合法合规保留现场记录', '联系平台客服报备'] },
  { id: 'accident', title: '交通事故', iconPath: '/images/scene_07.png', sceneId: 7, safety: true, evidence: ['确认人员与道路安全', '保存订单详情', '记录时间与定位', '拍摄现场照片或视频', '保存沟通记录', '联系平台客服'] },
  { id: 'fault', title: '车辆故障或电量不足', iconPath: '/images/scene_06.png', sceneId: 6, evidence: ['将车辆停至安全位置', '拍摄仪表盘或故障现场', '保存订单详情', '联系乘客说明情况', '保存维修拖车或充电凭证'] },
  { id: 'complaint', title: '恶意投诉或服务纠纷', iconPath: '/images/scene_10.png', sceneId: 10, evidence: ['避免与乘客争吵', '保存订单与行程轨迹', '保存完整沟通记录', '保留行车记录仪片段', '联系平台客服报备'] },
  { id: 'pet', title: '宠物或危险物品', iconPath: '/images/scene_12.png', sceneId: 12, evidence: ['先说明安全或卫生顾虑', '合法合规保留现场记录', '保存订单与沟通记录', '联系平台客服报备'] }
];

Page({
  data: { options: OPTIONS, selected: null, statuses: [], skipReasons: {}, currentIndex: 0, safety: false, skipMode: false, skipReason: '', completedCount: 0 },
  onLoad(options) { if (options.event) this.openEvent(options.event); },
  choose(e) { this.openEvent(e.currentTarget.dataset.id); },
  openEvent(id) {
    const selected = OPTIONS.find(item => item.id === id); if (!selected) return;
    const saved = getEmergencyProgress(id);
    const statuses = saved && saved.statuses && saved.statuses.length === selected.evidence.length ? saved.statuses : selected.evidence.map(() => 'pending');
    const firstPending = statuses.findIndex(item => item === 'pending');
    const currentIndex = saved && Number.isInteger(saved.currentIndex) ? Math.min(saved.currentIndex, selected.evidence.length - 1) : (firstPending >= 0 ? firstPending : selected.evidence.length - 1);
    this.setData({ selected, statuses, skipReasons: saved && saved.skipReasons ? saved.skipReasons : {}, currentIndex, safety: !!selected.safety, skipMode: false, skipReason: '', completedCount: statuses.filter(item => item !== 'pending').length });
  },
  persist() {
    if (!this.data.selected) return;
    saveEmergencyProgress(this.data.selected.id, { title: this.data.selected.title, statuses: this.data.statuses, skipReasons: this.data.skipReasons, currentIndex: this.data.currentIndex, completed: this.data.completedCount === this.data.selected.evidence.length });
  },
  selectStep(e) { this.setData({ currentIndex: Number(e.currentTarget.dataset.index), skipMode: false, skipReason: '' }); this.persist(); },
  completeCurrent() {
    const statuses = this.data.statuses.slice(); statuses[this.data.currentIndex] = 'done';
    const next = statuses.findIndex((item, index) => index > this.data.currentIndex && item === 'pending');
    const completedCount = statuses.filter(item => item !== 'pending').length;
    this.setData({ statuses, completedCount, currentIndex: next >= 0 ? next : this.data.currentIndex }); this.persist();
    if (completedCount === statuses.length) wx.showToast({ title: '现场清单已完成', icon: 'success' });
  },
  beginSkip() { this.setData({ skipMode: true, skipReason: this.data.skipReasons[this.data.currentIndex] || '' }); },
  onSkipInput(e) { this.setData({ skipReason: e.detail.value }); },
  confirmSkip() {
    const reason = (this.data.skipReason || '').trim(); if (!reason) { wx.showToast({ title: '请填写跳过原因', icon: 'none' }); return; }
    const statuses = this.data.statuses.slice(); const skipReasons = { ...this.data.skipReasons, [this.data.currentIndex]: reason };
    statuses[this.data.currentIndex] = 'skipped'; const next = statuses.findIndex((item, index) => index > this.data.currentIndex && item === 'pending');
    const completedCount = statuses.filter(item => item !== 'pending').length;
    this.setData({ statuses, skipReasons, completedCount, currentIndex: next >= 0 ? next : this.data.currentIndex, skipMode: false, skipReason: '' }); this.persist();
  },
  copyChecklist() {
    const text = `【${this.data.selected.title}现场处理清单】\n` + this.data.selected.evidence.map((item, i) => `${i + 1}. ${item}：${this.data.statuses[i] === 'done' ? '已完成' : this.data.statuses[i] === 'skipped' ? '已跳过（' + this.data.skipReasons[i] + '）' : '待处理'}`).join('\n');
    wx.setClipboardData({ data: text });
  },
  goAppeal() { if (this.data.selected.sceneId) wx.navigateTo({ url: `/pages/detail/detail?id=${this.data.selected.sceneId}` }); else wx.switchTab({ url: '/pages/category/category' }); },
  backToOptions() { this.persist(); this.setData({ selected: null, statuses: [], currentIndex: 0, skipMode: false }); },
  clearProgress() { if (!this.data.selected) return; clearEmergencyProgress(this.data.selected.id); this.openEvent(this.data.selected.id); }
});
