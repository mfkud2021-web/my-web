const { getAppealDrafts, clearBusinessData, clearWorkingData, getVehicleProfile, saveVehicleProfile } = require('../../utils/storage');

Page({
  data: { draftCount: 0, showVehiclePanel: false, vehicle: { plate: '', inspectionDate: '', maintenanceMileage: '' } },
  onShow() { this.setData({ draftCount: Object.keys(getAppealDrafts()).length, vehicle: { plate: '', inspectionDate: '', maintenanceMileage: '', ...getVehicleProfile() } }); },
  goFavorites() { wx.navigateTo({ url: '/pages/favorites/favorites' }); },
  goRecent() { wx.navigateTo({ url: '/pages/recent/recent' }); },
  goRules() { wx.navigateTo({ url: '/pages/knowledge/knowledge' }); },
  goAbout() { wx.navigateTo({ url: '/pages/about/about' }); },
  goDrafts() {
    wx.showModal({ title: '草稿与历史', content: this.data.draftCount ? `当前有 ${this.data.draftCount} 份未完成申诉草稿。进入申诉页后选择对应场景即可恢复。` : '当前没有未完成草稿，最近使用记录可在“最近使用”中查看。', confirmText: '进入申诉', success: res => { if (res.confirm) wx.switchTab({ url: '/pages/category/category' }); } });
  },
  showVehicle() { this.setData({ showVehiclePanel: true, vehicle: { plate: '', inspectionDate: '', maintenanceMileage: '', ...getVehicleProfile() } }); },
  closeVehicle() { this.setData({ showVehiclePanel: false }); },
  preventClose() {},
  onVehicleInput(e) { this.setData({ [`vehicle.${e.currentTarget.dataset.field}`]: e.detail.value }); },
  saveVehicle() {
    saveVehicleProfile(this.data.vehicle);
    this.setData({ showVehiclePanel: false });
    wx.showToast({ title: '车辆资料已保存', icon: 'success' });
  },
  showGuide() { wx.showModal({ title: '使用说明', content: '首页用于快速开始出车；申诉页生成文案和证据清单；经营页记录流水与成本；现场处理按步骤保存证据。所有数据仅保存在本机。', showCancel: false }); },
  feedback() { wx.setClipboardData({ data: 'mfkud@126.com', success: () => wx.showToast({ title: '反馈邮箱已复制', icon: 'success' }) }); },
  manageData() {
    wx.showActionSheet({ itemList: ['清除经营记录', '清除草稿和现场进度', '查看本地存储说明'], success: res => {
      if (res.tapIndex === 2) { wx.showModal({ title: '本地数据说明', content: '收藏、历史、申诉草稿、现场处理进度和经营记录均保存在本机微信小程序中，不会自动上传服务器。', showCancel: false }); return; }
      const business = res.tapIndex === 0;
      wx.showModal({ title: business ? '清除经营记录？' : '清除未完成任务？', content: '清除后无法恢复，请确认已备份需要的信息。', confirmColor: '#d92d20', success: modal => {
        if (!modal.confirm) return;
        if (business) clearBusinessData(); else clearWorkingData();
        this.onShow(); wx.showToast({ title: '已清除', icon: 'success' });
      }});
    }});
  }
});
