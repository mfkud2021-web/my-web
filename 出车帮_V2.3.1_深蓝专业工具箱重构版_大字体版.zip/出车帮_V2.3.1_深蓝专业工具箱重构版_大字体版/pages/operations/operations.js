const { getAllLedgers, getAllShifts, dateKey } = require('../../utils/storage');

const COST_KEYS = ['charging', 'parking', 'toll', 'fixed', 'other'];
const LABELS = { income: '平台流水', charging: '充电或油费', parking: '停车费用', toll: '高速费用', fixed: '车辆损耗/租金', other: '其他成本' };

Page({
  data: {
    period: 'today', net: '0.00', income: '0.00', cost: '0.00', duration: '0小时0分',
    netPerHour: '0.00', costPerKm: '0.00', records: []
  },
  onShow() { this.loadSummary(); },
  selectPeriod(e) { this.setData({ period: e.currentTarget.dataset.period }); this.loadSummary(); },
  getKeys() {
    const today = new Date();
    if (this.data.period === 'today') return [dateKey(today)];
    const keys = [];
    if (this.data.period === 'week') {
      for (let i = 6; i >= 0; i--) { const d = new Date(today); d.setDate(today.getDate() - i); keys.push(dateKey(d)); }
      return keys;
    }
    const year = today.getFullYear(); const month = today.getMonth();
    const days = new Date(year, month + 1, 0).getDate();
    for (let i = 1; i <= days; i++) keys.push(dateKey(new Date(year, month, i)));
    return keys;
  },
  loadSummary() {
    const ledgers = getAllLedgers(); const shifts = getAllShifts(); const keys = this.getKeys();
    const n = value => { const result = Number(value); return Number.isFinite(result) && result >= 0 ? result : 0; };
    let income = 0; let cost = 0; let mileage = 0; let minutes = 0;
    keys.forEach(key => {
      const ledger = ledgers[key] || {}; const shift = shifts[key] || {};
      income += n(ledger.income); cost += COST_KEYS.reduce((sum, item) => sum + n(ledger[item]), 0);
      mileage += n(ledger.mileage || shift.mileage);
      if (shift.startTimestamp && shift.endTimestamp) minutes += Math.max(0, Math.round((shift.endTimestamp - shift.startTimestamp) / 60000));
    });
    const todayLedger = ledgers[dateKey()] || {};
    const records = ['income', ...COST_KEYS].filter(key => n(todayLedger[key]) > 0).map(key => ({
      key, title: LABELS[key], amount: n(todayLedger[key]).toFixed(2), income: key === 'income'
    }));
    const hours = minutes / 60; const net = income - cost;
    this.setData({
      income: income.toFixed(2), cost: cost.toFixed(2), net: net.toFixed(2),
      duration: `${Math.floor(minutes / 60)}小时${minutes % 60}分`,
      netPerHour: hours > 0 ? (net / hours).toFixed(2) : '0.00',
      costPerKm: mileage > 0 ? (cost / mileage).toFixed(2) : '0.00', records
    });
  },
  goEarnings() { wx.navigateTo({ url: '/pages/earnings/earnings' }); },
  goShift() { wx.navigateTo({ url: '/pages/shift/shift' }); }
});
