const { SCENES, PLATFORMS, SCENE_INPUTS } = require('../../utils/templates');

const { copyText, formatDateTime, showToast } = require('../../utils/util');

const { isFavorite, toggleFavorite, addHistory, getPlatform, setPlatform, getEvidenceProgress, setEvidenceProgress, incrementCount, getAppealDraft, saveAppealDraft, removeAppealDraft } = require('../../utils/storage');



const pName = { didi: '滴滴', gaode: '高德', meituan: '美团', t3: 'T3出行', huaxiaozhu: '花小猪', common: '平台' };

const pNotes = {

  common: '各平台规则略有差异，请以实际平台为准',

  didi: '规则可能随城市和订单类型变化，请以当前订单页及客服说明为准',

  gaode: '高德为聚合平台，申诉需通过具体接单平台提交',

  meituan: '请以当前订单页及客服最新说明为准，并保存完整行程截图'

};



const INPUT_KEY_TO_PLACEHOLDER = {
  waitTime: '等待时长',
  newDestination: '修改后的目的地',
  dangerItem: '具体物品',
  jamReason: '堵车原因',
  faultDesc: '故障描述',
  accidentDesc: '事故概述',
  emergencyReason: '简要说明',
  behavior: '具体行为',
  showDistance: '显示距离',
  realDistance: '实际距离',
  remainingRange: '剩余续航',
  totalDistance: '全程距离'
};



Page({

  data: {

    scene: null, note: '', isFav: false, flowStep: 1, draftRestored: false,
    navHeight: 44,
    statusBarHeight: 20,
    menuTop: 4,
    showMenu: false,
    showHomeBtn: false, // 【新增修复代码】标记是否显示返回首页按钮（分享入口进入时显示）

    activeTab: 'short', evidenceChecked: [],

    fullStandard: '', shortText: '',

    platforms: PLATFORMS,

    platformId: 'common',

    platformNote: '',

    toast: '',

    evidenceProgress: 0,

    evidenceReadyCount: 0,

    autoTime: '',
    autoAddress: '',
    hasLocation: false,
    locationLoading: false,

    inputValues: {},
    sceneInputs: [],
    focusInput: '',
    showPosterPreview: false,
    posterUrl: '',
    requiredWarning: '',
    adviceTip: ''

  },



  onLoad(options) {

    const sys = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();
    const menu = wx.getMenuButtonBoundingClientRect ? wx.getMenuButtonBoundingClientRect() : null;
    const statusBarHeight = sys.statusBarHeight || 20;
    const navHeight = (menu ? menu.top - statusBarHeight + menu.height + 4 : 44);
    const menuTop = menu ? menu.top - statusBarHeight : 4;
    this.setData({ statusBarHeight, navHeight, menuTop });

    // 从分享卡片/扫码等场景直接进入时页面栈只有 1 页，navigateBack 无处可退，需显示返回首页按钮
    const isDirectEntry = getCurrentPages().length === 1;
    this.setData({ showHomeBtn: isDirectEntry || options.from === 'share' });

    const id = parseInt(options.id, 10);

    const scene = SCENES.find(s => s.id === id);

    if (!scene) {

      wx.showToast({ title: '场景不存在', icon: 'none' });

      wx.switchTab({ url: '/pages/index/index' }); return;

    }

    addHistory(id);

    const pid = getPlatform();
    const now = formatDateTime();
    const inputs = SCENE_INPUTS[id] || [];
    const savedEvidence = getEvidenceProgress(id);
    const evidenceChecked = savedEvidence.length === scene.evidence.length
      ? savedEvidence
      : scene.evidence.map(() => false);
    const ready = evidenceChecked.filter(Boolean).length;
    const progress = scene.evidence.length > 0 ? ready / scene.evidence.length * 100 : 0;

    const draft = getAppealDraft(id);
    const draftEvidence = draft && Array.isArray(draft.evidenceChecked) && draft.evidenceChecked.length === scene.evidence.length ? draft.evidenceChecked : evidenceChecked;
    const draftReady = draftEvidence.filter(Boolean).length;
    this.setData({

      scene: { ...scene },

      isFav: isFavorite(id),

      evidenceChecked: draftEvidence,

      evidenceReadyCount: draftReady,
      evidenceProgress: scene.evidence.length ? draftReady / scene.evidence.length * 100 : progress,

      platformId: draft && draft.platformId ? draft.platformId : pid,

      platformNote: pNotes[draft && draft.platformId ? draft.platformId : pid] || '',

      autoTime: draft && draft.autoTime ? draft.autoTime : now,

      sceneInputs: inputs,
      inputValues: draft && draft.inputValues ? draft.inputValues : {},
      note: draft && draft.note ? draft.note : '',
      autoAddress: draft && draft.autoAddress ? draft.autoAddress : '',
      hasLocation: !!(draft && draft.autoAddress),
      activeTab: draft && draft.activeTab ? draft.activeTab : 'short',
      flowStep: draft && draft.step ? draft.step : 1,
      draftRestored: !!draft,
      focusInput: ''

    });

    this.rebuildTexts();
    if (draft) showToast('已恢复上次草稿');

  },



  onNoteInput(e) {

    this.setData({ note: e.detail.value });

    this.rebuildTexts();

  },



  selectPlatform(e) {

    const pid = e.currentTarget.dataset.id;

    setPlatform(pid);

    this.setData({ platformId: pid, platformNote: pNotes[pid] || '' });

    this.rebuildTexts();

  },



  rebuildTexts() {

    this._draftCleared = false;

    const base = this.data.scene;

    if (!base) return;

    const name = pName[this.data.platformId] || '';

    let std = base.standard;
    let sht = base.short;

    const inputValues = this.data.inputValues || {};
    const inputs = this.data.sceneInputs || [];

    // 1. 替换平台
    std = std.replace(/\[平台\]/g, name);
    sht = sht.replace(/\[平台\]/g, name);

    // 2. 替换自动填充（时间、地点）
    const time = this.data.autoTime || formatDateTime();
    const addr = this.data.autoAddress || '';
    std = std.replace(/\[订单时间\]/g, time);
    std = std.replace(/\[时间\]/g, time);
    std = std.replace(/\[地点\]/g, addr);
    std = std.replace(/\[路段\]/g, addr);
    sht = sht.replace(/\[订单时间\]/g, time);
    sht = sht.replace(/\[时间\]/g, time);
    sht = sht.replace(/\[地点\]/g, addr);
    sht = sht.replace(/\[路段\]/g, addr);

    // 3. 替换动态输入项
    const unfilled = [];

    inputs.forEach(input => {
      let value = inputValues[input.key];

      // 故障类型特殊处理：选了"其它"用 faultOther
      if (input.key === 'faultDesc' && value === '其它') {
        value = inputValues.faultOther || '';
      }

      const placeholder = INPUT_KEY_TO_PLACEHOLDER[input.key];
      if (placeholder) {
        const regex = new RegExp('\\[' + placeholder + '\\]', 'g');
        if (value) {
          std = std.replace(regex, value);
          sht = sht.replace(regex, value);
        }
      }

      // 检查必填项是否填写
      if (input.required && (!value || String(value).trim() === '')) {
        unfilled.push(input.label + (input.unit ? '（' + input.unit + '）' : ''));
      }
    });

    // 4. 场景11：自动计算差额
    const showDist = inputValues.showDistance;
    const realDist = inputValues.realDistance;
    if (showDist && realDist) {
      const s = parseFloat(showDist);
      const r = parseFloat(realDist);
      if (!isNaN(s) && !isNaN(r)) {
        const diff = (r - s).toFixed(1);
        std = std.replace(/\[差额\]/g, diff);
        sht = sht.replace(/\[差额\]/g, diff);
      }
    }

    // 5. 补充内容拼接到末尾
    if (this.data.note) {
      std += '\n\n【补充内容】' + this.data.note;
      sht += ' 【补充】' + this.data.note;
    }

    // 6. 必填项警告（阻塞流程）与场景智能提示（仅展示）分开
    const requiredWarning = unfilled.length ? '请填写：' + unfilled.join('、') : '';

    // 场景专属校验
    const advices = [];
    const sceneId = this.data.scene.id;
    const iv = this.data.inputValues;
    if (sceneId === 13 && iv.remainingRange && iv.totalDistance) {
      const rr = parseFloat(iv.remainingRange);
      const td = parseFloat(iv.totalDistance);
      if (!isNaN(rr) && !isNaN(td) && rr < td) {
        advices.push('剩余续航不足以完成全程，建议补充充电记录');
      }
    }
    if (sceneId === 11 && iv.showDistance && iv.realDistance) {
      const sd = parseFloat(iv.showDistance);
      const rd = parseFloat(iv.realDistance);
      if (!isNaN(sd) && !isNaN(rd) && (rd - sd) > 3) {
        advices.push('差额超过3公里，建议截图报备');
      }
    }
    if (sceneId === 1 && iv.waitTime) {
      const wt = parseFloat(iv.waitTime);
      if (!isNaN(wt) && wt < 3) {
        advices.push('等待时长较短，建议确认平台免费等待时间');
      }
    }

    this.setData({ fullStandard: std, shortText: sht, requiredWarning, adviceTip: advices.join('；') });

  },



  copyStandard() { copyText(this.data.fullStandard); if (this.data.scene) { incrementCount(this.data.scene.id); removeAppealDraft(this.data.scene.id); this._draftCleared = true; } },
  copyShort() { copyText(this.data.shortText); if (this.data.scene) { incrementCount(this.data.scene.id); removeAppealDraft(this.data.scene.id); this._draftCleared = true; } },

  nextFlowStep() {
    if (this.data.flowStep === 2 && this.data.requiredWarning) {
      showToast(this.data.requiredWarning, 2200);
      this.scrollToFirstUnfilled();
      return;
    }
    const next = Math.min(4, this.data.flowStep + 1);
    this.setData({ flowStep: next });
    this.saveDraft(false);
  },

  previousFlowStep() {
    this.setData({ flowStep: Math.max(1, this.data.flowStep - 1) });
  },

  onHide() { this.saveDraft(false); },

  onUnload() { this.saveDraft(false); },

  onSaveDraftTap() { this.saveDraft(true); },

  saveDraft(showMessage = true) {
    if (!this.data.scene || this._draftCleared) return;
    saveAppealDraft(this.data.scene.id, {
      sceneName: this.data.scene.name,
      step: this.data.flowStep,
      inputValues: this.data.inputValues,
      note: this.data.note,
      platformId: this.data.platformId,
      autoTime: this.data.autoTime,
      autoAddress: this.data.autoAddress,
      evidenceChecked: this.data.evidenceChecked,
      activeTab: this.data.activeTab
    });
    if (showMessage) showToast('草稿已保存');
  },

  refreshTime() {
    const now = formatDateTime();
    this.setData({ autoTime: now });
    this.rebuildTexts();
    showToast('时间已刷新');
  },

  chooseLocation() {
    this.setData({ locationLoading: true });
    wx.chooseLocation({
      success: (res) => {
        const addr = res.name || res.address || '未知位置';
        this.setData({ autoAddress: addr, hasLocation: true, locationLoading: false });
        this.rebuildTexts();
        showToast('位置已获取');
      },
      fail: (err) => {
        this.setData({ locationLoading: false });
        if (err.errMsg && err.errMsg.includes('cancel')) return;
        wx.showModal({
          title: '定位失败',
          content: '无法获取位置，可以手动输入地址',
          showCancel: false
        });
      }
    });
  },

  clearLocation() {
    this.setData({ autoAddress: '', hasLocation: false });
    this.rebuildTexts();
  },



  // 动态输入项处理
  onDynamicInput(e) {
    const key = e.currentTarget.dataset.key;
    const value = e.detail.value;
    const inputValues = { ...this.data.inputValues, [key]: value };
    this.setData({ inputValues });
    this.rebuildTexts();
  },

  onVoiceInput(e) {
    // 微信小程序无内置免费语音转文字 API，需接入腾讯云/百度/讯飞等第三方服务
    // 当前为降级提示：引导用户使用系统键盘语音输入
    wx.showModal({
      title: '语音输入',
      content: '请使用手机键盘自带的麦克风按钮进行语音输入。如需接入自动语音识别，需配置第三方语音 API。',
      showCancel: false,
      confirmText: '知道了'
    });
  },

  onSelectFault(e) {
    const type = e.currentTarget.dataset.type;
    const inputValues = { ...this.data.inputValues, faultDesc: type };
    if (type !== '其它') {
      delete inputValues.faultOther;
    }
    this.setData({ inputValues });
    this.rebuildTexts();
  },

  onFaultOtherInput(e) {
    const value = e.detail.value;
    const inputValues = { ...this.data.inputValues, faultOther: value };
    this.setData({ inputValues });
    this.rebuildTexts();
  },

  scrollToInput(e) {
    const key = e.currentTarget.dataset.key;
    this.setData({ focusInput: key });
  },

  scrollToFirstUnfilled() {
    const inputs = this.data.sceneInputs || [];
    const inputValues = this.data.inputValues || {};
    for (const input of inputs) {
      let value = inputValues[input.key];
      if (input.key === 'faultDesc' && value === '其它') {
        value = inputValues.faultOther || '';
      }
      if (input.required && (!value || String(value).trim() === '')) {
        this.setData({ focusInput: '' });
        wx.nextTick(() => {
          this.setData({ focusInput: input.key });
        });
        return;
      }
    }
  },



  switchTab(e) { this.setData({ activeTab: e.currentTarget.dataset.tab }); },



  toggleEv(e) {

    const idx = e.currentTarget.dataset.idx;

    const c = [...this.data.evidenceChecked];

    c[idx] = !c[idx];

    const ready = c.filter(Boolean).length;

    const progress = this.data.scene.evidence.length > 0 ? ready / this.data.scene.evidence.length * 100 : 0;

    this.setData({ evidenceChecked: c, evidenceReadyCount: ready, evidenceProgress: progress });

    setEvidenceProgress(this.data.scene.id, c);

  },



  toggleFav() {

    const n = toggleFavorite(this.data.scene.id);

    this.setData({ isFav: n });

    showToast(n ? '已收藏' : '已取消收藏');

  },



  // ========== 分享功能改造：新增修复代码开始 ==========
  // 【改造说明】原方法名为 shareAppMessage()，微信小程序框架要求固定为 onShareAppMessage 才能被自动调用。
  // 转发微信好友时携带 from=share 参数，用于接收方判断是从分享卡片进入。
  onShareAppMessage() {
    return {
      title: this.data.scene.name + ' - 申诉话术模板',
      path: '/pages/detail/detail?id=' + this.data.scene.id + '&from=share'
    };
  },

  // 分享到朋友圈（新增），query 中同样携带 from=share 参数
  onShareTimeline() {
    return {
      title: this.data.scene.name + ' - 申诉话术模板',
      query: 'id=' + this.data.scene.id + '&from=share'
    };
  },
  // ========== 分享功能改造：新增修复代码结束 ==========

  // ========== 海报生成 ==========
  generatePoster() {
    const { scene, platformId, fullStandard, autoTime } = this.data;
    if (!scene || !fullStandard) {
      showToast('请先生成话术');
      return;
    }

    showToast('正在生成海报...', 2000);

    const query = wx.createSelectorQuery();
    query.select('#posterCanvas').fields({ node: true, size: true }).exec((res) => {
      if (!res[0] || !res[0].node) {
        showToast('Canvas 初始化失败');
        return;
      }

      const canvas = res[0].node;
      const ctx = canvas.getContext('2d');
      const dpr = (wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync()).pixelRatio;
      const width = 750;
      const padding = 50;

      ctx.font = '28px sans-serif';
      const maxWidth = width - padding * 2;
      const lines = [];
      fullStandard.split('\n').forEach(paragraph => {
        if (!paragraph) { lines.push(''); return; }
        let line = '';
        for (let i = 0; i < paragraph.length; i++) {
          const char = paragraph[i];
          if (ctx.measureText(line + char).width > maxWidth) {
            lines.push(line);
            line = char;
          } else {
            line += char;
          }
        }
        lines.push(line);
      });

      const lineHeight = 48;
      const contentHeight = lines.length * lineHeight;
      const height = Math.max(1000, 60 + 140 + 30 + contentHeight + 100 + 60);

      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.scale(dpr, dpr);

      // 背景
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);

      // 顶部品牌色条，与全局设计系统保持一致
      ctx.fillStyle = '#1456c0';
      ctx.fillRect(0, 0, width, 8);

      // 场景标题
      ctx.fillStyle = '#1a1a2e';
      ctx.font = 'bold 40px sans-serif';
      ctx.fillText(scene.name, padding, 80);

      // 平台标签
      ctx.fillStyle = '#1456c0';
      ctx.font = '24px sans-serif';
      const platformName = pName[platformId] || '平台';
      ctx.fillText('适用平台：' + platformName, padding, 120);

      // 分隔线
      ctx.strokeStyle = '#e8e8ee';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(padding, 150);
      ctx.lineTo(width - padding, 150);
      ctx.stroke();

      // 话术内容
      ctx.fillStyle = '#333333';
      ctx.font = '28px sans-serif';
      let y = 200;
      lines.forEach(l => {
        ctx.fillText(l, padding, y);
        y += lineHeight;
      });

      // 底部
      ctx.strokeStyle = '#e8e8ee';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(padding, height - 100);
      ctx.lineTo(width - padding, height - 100);
      ctx.stroke();

      ctx.fillStyle = '#999999';
      ctx.font = '22px sans-serif';
      ctx.fillText('生成时间：' + autoTime, padding, height - 50);
      ctx.fillText('出车帮', width - padding - ctx.measureText('出车帮').width, height - 50);

      wx.canvasToTempFilePath({
        canvas: canvas,
        success: (r) => {
          this.setData({ showPosterPreview: true, posterUrl: r.tempFilePath });
        },
        fail: () => showToast('生成失败，请重试')
      });
    });
  },

  savePoster() {
    wx.saveImageToPhotosAlbum({
      filePath: this.data.posterUrl,
      success: () => showToast('已保存到相册'),
      fail: (err) => {
        if (err.errMsg && err.errMsg.includes('auth deny')) {
          wx.showModal({
            title: '需要授权',
            content: '请允许保存图片到相册',
            success: (r) => { if (r.confirm) wx.openSetting(); }
          });
        } else {
          showToast('保存失败');
        }
      }
    });
  },

  closePosterPreview() {
    this.setData({ showPosterPreview: false });
  },

  // ========== 返回首页：新增修复代码开始 ==========
  // 点击导航栏返回首页按钮，使用 switchTab 跳转到 tabBar 首页（首页为 tabBar 页面，不能用 navigateTo）
  goHome() {
    wx.switchTab({ url: '/pages/index/index' });
  },
  // ========== 返回首页：新增修复代码结束 ==========

  goBack() {
    if (getCurrentPages().length > 1) wx.navigateBack();
    else wx.switchTab({ url: '/pages/index/index' });
  },

  showMoreMenu() {
    this.setData({ showMenu: true });
  },

  hideMenu() {
    this.setData({ showMenu: false });
  },

  preventHide() {
    // do nothing, just prevent bubbling
  },

  toggleFavFromMenu() {
    this.toggleFav();
    this.hideMenu();
  },

});
