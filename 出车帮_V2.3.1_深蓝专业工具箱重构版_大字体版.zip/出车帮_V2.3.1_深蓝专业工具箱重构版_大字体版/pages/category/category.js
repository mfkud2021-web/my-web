const { SCENES } = require('../../utils/templates');
const { isFavorite, getHistory } = require('../../utils/storage');

Page({
  data: {
    scenes: [], filtered: [], common: [], recent: [], keyword: '', activeCategory: 'all',
    toast: ''
  },

  onLoad() {
    this.loadScenes();
  },

  onShow() {
    this.loadScenes();
  },

  loadScenes() {
    const scenes = SCENES.map(s => ({ ...s, fav: isFavorite(s.id) }));
    const recent = getHistory().slice(0, 4).map(id => scenes.find(s => s.id === id)).filter(Boolean);
    const preferred = [1, 2, 6, 9];
    const common = preferred.map(id => scenes.find(s => s.id === id)).filter(Boolean);
    this.setData({ scenes, filtered: scenes, common, recent, keyword: '', activeCategory: 'all' });
  },
  onSearch(e) { this.setData({ keyword: e.detail.value }); this.applyFilter(e.detail.value, this.data.activeCategory); },
  selectCategory(e) { const c=e.currentTarget.dataset.category; this.setData({activeCategory:c}); this.applyFilter(this.data.keyword,c); },
  applyFilter(keyword, category) {
    const groups={passenger:[1,2,3,4,9,12],order:[5,8,10,11],vehicle:[6,7,13],review:[10,11]};
    const key=(keyword||'').trim().toLowerCase();
    const filtered=this.data.scenes.filter(s=>(category==='all'||(groups[category]||[]).includes(s.id))&&(!key||s.name.toLowerCase().includes(key)||s.short.toLowerCase().includes(key)));
    this.setData({filtered});
  },
  goRecent(){wx.navigateTo({url:'/pages/recent/recent'})},

  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/detail/detail?id=${id}` });
  }
});
