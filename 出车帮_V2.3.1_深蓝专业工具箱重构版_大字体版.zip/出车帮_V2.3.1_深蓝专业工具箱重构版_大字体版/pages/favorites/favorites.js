const { SCENES } = require('../../utils/templates');
const { getFavorites } = require('../../utils/storage');

Page({
  data: {
    scenes: [],
    empty: false,
    toast: ''
  },

  onShow() {
    this.loadFavorites();
  },

  loadFavorites() {
    const ids = getFavorites();
    if (ids.length === 0) {
      this.setData({ scenes: [], empty: true });
      return;
    }
    const scenes = ids.map(id => {
      const s = SCENES.find(sc => sc.id === id);
      if (!s) return null;
      return { ...s };
    }).filter(Boolean);
    this.setData({ scenes, empty: scenes.length === 0 });
  },

  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/detail/detail?id=${id}` });
  }
});
