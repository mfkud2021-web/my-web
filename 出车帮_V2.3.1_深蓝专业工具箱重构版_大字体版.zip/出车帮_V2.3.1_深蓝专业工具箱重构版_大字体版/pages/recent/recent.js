const { SCENES }=require('../../utils/templates');
const { getHistory, clearHistory }=require('../../utils/storage');
Page({
 data:{scenes:[],empty:true},
 onShow(){const scenes=getHistory().map(id=>SCENES.find(s=>s.id===id)).filter(Boolean);this.setData({scenes,empty:!scenes.length})},
 goDetail(e){wx.navigateTo({url:`/pages/detail/detail?id=${e.currentTarget.dataset.id}`})},
 clear(){wx.showModal({title:'清空最近使用',content:'清空后无法恢复，是否继续？',success:r=>{if(r.confirm){clearHistory();this.setData({scenes:[],empty:true})}}})}
});
