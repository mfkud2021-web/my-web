const { KNOWLEDGE, TIPS } = require('../../utils/templates');

Page({
  data: {
    items: [],
    tips: [],
    activeIdx: 0,
    toast: ''
  },

  onLoad() {
    this.setData({ items: KNOWLEDGE, tips: TIPS });
  },

  toggleExpand(e) {
    const idx = e.currentTarget.dataset.idx;
    this.setData({ activeIdx: this.data.activeIdx === idx ? -1 : idx });
  },

  goAbout() {
    wx.navigateTo({ url: '/pages/about/about' });
  }
});
