Page({
  data: {
    toast: ''
  },

  copyEmail() {
    wx.setClipboardData({
      data: 'mfkud@126.com',
      success: () => {
        wx.showToast({ title: '邮箱已复制', icon: 'none' });
      }
    });
  }
});