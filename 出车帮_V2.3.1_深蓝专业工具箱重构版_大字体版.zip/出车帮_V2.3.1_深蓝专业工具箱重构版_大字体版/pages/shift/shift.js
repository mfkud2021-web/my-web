const { dateKey, getTodayShift, saveTodayShift, getTodayLedger, saveTodayLedger } = require('../../utils/storage');

Page({
  data: {
    date: '', status: 'idle', startTime: '', endTime: '', startTimestamp: 0, endTimestamp: 0,
    durationText: '--', elapsedText: '00:00:00', startMileage: '', endMileage: '', mileage: '',
    emptyMileage: '', orders: '', income: '', charging: '', parking: '', toll: '', fixed: '', other: '', note: ''
  },
  onLoad() {
    const saved = getTodayShift();
    const ledger = getTodayLedger();
    this.setData({
      date: dateKey(), ...saved,
      startMileage: saved.startMileage || '', endMileage: saved.endMileage || '',
      income: saved.income !== undefined && saved.income !== '' ? saved.income : (ledger.income || ''),
      orders: saved.orders !== undefined && saved.orders !== '' ? saved.orders : (ledger.orders || ''),
      mileage: saved.mileage !== undefined && saved.mileage !== '' ? saved.mileage : (ledger.mileage || ''),
      charging: ledger.charging || '', parking: ledger.parking || '', toll: ledger.toll || '', fixed: ledger.fixed || '', other: ledger.other || ''
    });
    this.updateElapsed();
  },
  onShow() { this.startTimer(); },
  onHide() { this.stopTimer(); this.persist(); },
  onUnload() { this.stopTimer(); this.persist(); },
  startTimer() { this.stopTimer(); if (this.data.status === 'running') this.timer = setInterval(() => this.updateElapsed(), 1000); },
  stopTimer() { if (this.timer) { clearInterval(this.timer); this.timer = null; } },
  updateElapsed() {
    if (!this.data.startTimestamp) return;
    const end = this.data.status === 'done' && this.data.endTimestamp ? this.data.endTimestamp : Date.now();
    const seconds = Math.max(0, Math.floor((end - this.data.startTimestamp) / 1000));
    const h = String(Math.floor(seconds / 3600)).padStart(2, '0');
    const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
    const s = String(seconds % 60).padStart(2, '0');
    this.setData({ elapsedText: `${h}:${m}:${s}`, durationText: `${Math.floor(seconds / 3600)}小时${Math.floor((seconds % 3600) / 60)}分钟` });
  },
  formatTime(date) { return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`; },
  startShift() {
    const now = new Date();
    this.setData({ status: 'running', startTime: this.formatTime(now), startTimestamp: now.getTime(), endTime: '', endTimestamp: 0, durationText: '0小时0分钟', elapsedText: '00:00:00' });
    this.persist(); this.startTimer();
  },
  endShift() {
    wx.showModal({ title: '结束本次出车？', content: '结束后可以继续补充流水、订单和成本。', success: res => {
      if (!res.confirm) return;
      const now = new Date(); this.setData({ status: 'done', endTime: this.formatTime(now), endTimestamp: now.getTime() });
      this.updateMileage(); this.updateElapsed(); this.persist(); this.stopTimer();
    }});
  },
  onInput(e) { this.setData({ [e.currentTarget.dataset.field]: e.detail.value }); if (['startMileage', 'endMileage'].includes(e.currentTarget.dataset.field)) this.updateMileage(); },
  updateMileage() {
    const start = Number(this.data.startMileage); const end = Number(this.data.endMileage);
    if (Number.isFinite(start) && Number.isFinite(end) && end >= start) this.setData({ mileage: (end - start).toFixed(1) });
  },
  persist() {
    const fields = ['status','startTime','endTime','startTimestamp','endTimestamp','durationText','startMileage','endMileage','mileage','emptyMileage','orders','income','note'];
    const data = {}; fields.forEach(key => { data[key] = this.data[key]; }); saveTodayShift(data);
    const ledger = getTodayLedger();
    ledger.income = this.data.income;
    ledger.mileage = this.data.mileage;
    ledger.orders = this.data.orders;
    ['charging', 'parking', 'toll', 'fixed', 'other'].forEach(key => {
      ledger[key] = this.data[key];
    });
    saveTodayLedger(ledger);
  },
  save() { this.updateMileage(); this.persist(); wx.showToast({ title: '记录已保存', icon: 'success' }); },
  goEarnings() { this.persist(); wx.navigateTo({ url: '/pages/earnings/earnings' }); },
  reset() {
    wx.showModal({ title: '清空今日记录？', content: '清空后无法恢复。', success: res => {
      if (!res.confirm) return;
      const empty = { status:'idle', startTime:'', endTime:'', startTimestamp:0, endTimestamp:0, durationText:'--', elapsedText:'00:00:00', startMileage:'', endMileage:'', mileage:'', emptyMileage:'', orders:'', income:'', charging:'', parking:'', toll:'', fixed:'', other:'', note:'' };
      this.setData(empty); saveTodayShift(empty); saveTodayLedger({}); this.stopTimer();
    }});
  }
});
