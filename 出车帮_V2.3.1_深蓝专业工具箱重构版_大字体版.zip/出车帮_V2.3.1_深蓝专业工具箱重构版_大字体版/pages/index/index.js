const { SCENES } = require('../../utils/templates');
const { getHistory, getTodayLedger, getTodayShift, getPendingTask } = require('../../utils/storage');

Page({
  data: {
    todayNet: '0.00', todayIncome: '0.00', todayCost: '0.00', duration: '未开始',
    recentName: '暂无使用记录', recentId: null, shiftStatus: '今天还未开始出车',
    shiftAction: '开始出车', pendingTask: null
  },
  onShow() { this.loadOverview(); },
  loadOverview() {
    const ledger = getTodayLedger();
    const income = this.toNumber(ledger.income);
    const cost = ['charging', 'parking', 'toll', 'other', 'fixed'].reduce((sum, key) => sum + this.toNumber(ledger[key]), 0);
    const history = getHistory();
    const recent = history.length ? SCENES.find(item => item.id === history[0]) : null;
    const shift = getTodayShift();
    let shiftStatus = '今天还未开始出车';
    let shiftAction = '开始出车';
    if (shift.startTime && !shift.endTime) { shiftStatus = `出车中 · ${shift.startTime}`; shiftAction = '继续出车'; }
    if (shift.startTime && shift.endTime) { shiftStatus = `已收车 · ${shift.durationText || '--'}`; shiftAction = '查看记录'; }
    this.setData({
      todayNet: (income - cost).toFixed(2), todayIncome: income.toFixed(2), todayCost: cost.toFixed(2),
      duration: shift.durationText || (shift.startTime ? '进行中' : '未开始'),
      recentName: recent ? recent.name : '暂无使用记录', recentId: recent ? recent.id : null,
      shiftStatus, shiftAction, pendingTask: getPendingTask()
    });
  },
  toNumber(value) { const n = Number(value); return Number.isFinite(n) && n >= 0 ? n : 0; },
  goAppeals() { wx.switchTab({ url: '/pages/category/category' }); },
  goEarnings() { wx.navigateTo({ url: '/pages/earnings/earnings' }); },
  goEmergency() { wx.navigateTo({ url: '/pages/emergency/emergency' }); },
  goShift() { wx.navigateTo({ url: '/pages/shift/shift' }); },
  goOperations() { wx.switchTab({ url: '/pages/operations/operations' }); },
  goProfile() { wx.switchTab({ url: '/pages/profile/profile' }); },
  goRules() { wx.navigateTo({ url: '/pages/knowledge/knowledge' }); },
  goFavorites() { wx.navigateTo({ url: '/pages/favorites/favorites' }); },
  goRecent() { wx.navigateTo({ url: '/pages/recent/recent' }); },
  goPending() {
    const task = this.data.pendingTask;
    if (!task || !task.url) return;
    wx.navigateTo({ url: task.url });
  }
});
