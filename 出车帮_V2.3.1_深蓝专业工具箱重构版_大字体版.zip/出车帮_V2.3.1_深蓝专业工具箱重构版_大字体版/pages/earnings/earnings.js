const { getTodayLedger, saveTodayLedger, getTodayShift, dateKey } = require('../../utils/storage');

Page({
  data: {
    date: '', income: '', charging: '', parking: '', toll: '', other: '', fixed: '',
    mileage: '', kwh: '', orders: '', hours: '', totalCost: '0.00', net: '0.00', costPerKm: '0.00', incomePerKm: '0.00', incomePerOrder: '0.00', netPerHour: '0.00', chargingRatio: '0.0', energyPer100Km: '0.0', saved: false
  },

  onLoad() {
    const ledger = getTodayLedger();
    const shift = getTodayShift();
    let hours = '';
    if (shift.startTimestamp) hours = (((shift.endTimestamp || Date.now()) - shift.startTimestamp) / 3600000).toFixed(2);
    this.setData({ date: dateKey(), ...ledger, orders: shift.orders || ledger.orders || '', hours });
    this.calculate();
  },

  onInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({ [field]: e.detail.value, saved: false });
    this.calculate();
  },

  calculate() {
    const n = key => { const value = Number(this.data[key]); return Number.isFinite(value) && value >= 0 ? value : 0; };
    const totalCost = n('charging') + n('parking') + n('toll') + n('other') + n('fixed');
    const mileage = n('mileage');
    this.setData({
      totalCost: totalCost.toFixed(2),
      net: (n('income') - totalCost).toFixed(2),
      costPerKm: mileage > 0 ? (totalCost / mileage).toFixed(2) : '0.00',
      incomePerKm: mileage > 0 ? (n('income') / mileage).toFixed(2) : '0.00',
      incomePerOrder: n('orders') > 0 ? (n('income') / n('orders')).toFixed(2) : '0.00',
      netPerHour: n('hours') > 0 ? ((n('income') - totalCost) / n('hours')).toFixed(2) : '0.00',
      chargingRatio: n('income') > 0 ? (n('charging') / n('income') * 100).toFixed(1) : '0.0',
      energyPer100Km: mileage > 0 ? (n('kwh') / mileage * 100).toFixed(1) : '0.0'
    });
  },

  save() {
    const fields = ['income', 'charging', 'parking', 'toll', 'other', 'fixed', 'mileage', 'kwh', 'orders'];
    const data = {};
    fields.forEach(key => { data[key] = this.data[key]; });
    saveTodayLedger(data);
    this.setData({ saved: true });
    wx.showToast({ title: '今日数据已保存', icon: 'success' });
  }
});
