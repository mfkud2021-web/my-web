const fs = require('fs');
const path = 'C:/Users/mfkud/Documents/New project/司机申诉助手/utils/templates.js';
let content = fs.readFileSync(path, 'utf8');

// Fix undefined icon fields - replace 'undefined\n    updated' with proper icon path
let idx = 1;
content = content.replace(/undefined\n    updated/g, () => {
  const num = String(idx).padStart(2, '0');
  idx++;
  return `icon: '/images/scene_${num}.svg',\n    updated`;
});

fs.writeFileSync(path, content);
console.log('Fixed all icon paths');

// Verify
const verify = fs.readFileSync(path, 'utf8');
const matches = verify.match(/icon:.*/g);
console.log(matches.slice(0, 12).join('\n'));
