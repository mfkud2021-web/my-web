function showToast(msg, duration) {
  const d = duration || 1500;
  const page = getCurrentPages().pop();
  if (!page) return;
  if (page._toastTimer) clearTimeout(page._toastTimer);
  page.setData({ toast: msg });
  page._toastTimer = setTimeout(() => {
    page.setData({ toast: '' });
    page._toastTimer = null;
  }, d);
}

function copyText(text) {
  wx.setClipboardData({
    data: text,
    success: () => showToast('已复制到剪贴板')
  });
}

function formatDateTime(date) {
  const d = date || new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const h = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  return `${y}年${m}月${day}日 ${h}:${min}`;
}

module.exports = { showToast, copyText, formatDateTime };
