function getFavorites() {
  try { return wx.getStorageSync('favorites') || []; } catch (e) { return []; }
}
function isFavorite(id) {
  return getFavorites().indexOf(id) !== -1;
}
function toggleFavorite(id) {
  let favs = getFavorites();
  const idx = favs.indexOf(id);
  if (idx === -1) { favs.push(id); } else { favs.splice(idx, 1); }
  wx.setStorageSync('favorites', favs);
  return idx === -1;
}

function getHistory() {
  try { return wx.getStorageSync('history') || []; } catch (e) { return []; }
}
function addHistory(sceneId) {
  let h = getHistory();
  h = h.filter(id => id !== sceneId);
  h.unshift(sceneId);
  if (h.length > 50) h = h.slice(0, 50);
  wx.setStorageSync('history', h);
}
function clearHistory() { wx.setStorageSync('history', []); }

function getPlatform() {
  try { return wx.getStorageSync('platform') || 'common'; } catch (e) { return 'common'; }
}
function setPlatform(id) { wx.setStorageSync('platform', id); }

function getEvidenceProgress(sceneId) {
  try {
    const all = wx.getStorageSync('evidence_progress') || {};
    return all[sceneId] || [];
  } catch (e) { return []; }
}

function setEvidenceProgress(sceneId, checkedArr) {
  try {
    const all = wx.getStorageSync('evidence_progress') || {};
    all[sceneId] = checkedArr;
    wx.setStorageSync('evidence_progress', all);
  } catch (e) {}
}

function getAllCounts() {
  try { return wx.getStorageSync('scene_counts') || {}; } catch (e) { return {}; }
}

function getCount(id) {
  const all = getAllCounts();
  return all[id] || 0;
}

function incrementCount(id) {
  const all = getAllCounts();
  all[id] = (all[id] || 0) + 1;
  wx.setStorageSync('scene_counts', all);
}

function dateKey(date) {
  const d = date || new Date();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

function getLedger(date) {
  try {
    const all = wx.getStorageSync('daily_ledgers') || {};
    return all[date || dateKey()] || {};
  } catch (e) { return {}; }
}

function getTodayLedger() { return getLedger(dateKey()); }

function saveTodayLedger(data) {
  const all = wx.getStorageSync('daily_ledgers') || {};
  all[dateKey()] = data;
  wx.setStorageSync('daily_ledgers', all);
}

function getTodayShift() {
  try {
    const all = wx.getStorageSync('daily_shifts') || {};
    return all[dateKey()] || {};
  } catch (e) { return {}; }
}

function saveTodayShift(data) {
  const all = wx.getStorageSync('daily_shifts') || {};
  all[dateKey()] = data;
  wx.setStorageSync('daily_shifts', all);
}

function getAllLedgers() {
  try { return wx.getStorageSync('daily_ledgers') || {}; } catch (e) { return {}; }
}

function getAllShifts() {
  try { return wx.getStorageSync('daily_shifts') || {}; } catch (e) { return {}; }
}

function getAppealDraft(sceneId) {
  try {
    const all = wx.getStorageSync('appeal_drafts') || {};
    return all[sceneId] || null;
  } catch (e) { return null; }
}

function saveAppealDraft(sceneId, draft) {
  try {
    const all = wx.getStorageSync('appeal_drafts') || {};
    all[sceneId] = { ...draft, sceneId, updatedAt: Date.now() };
    wx.setStorageSync('appeal_drafts', all);
  } catch (e) {}
}

function removeAppealDraft(sceneId) {
  try {
    const all = wx.getStorageSync('appeal_drafts') || {};
    delete all[sceneId];
    wx.setStorageSync('appeal_drafts', all);
  } catch (e) {}
}

function getAppealDrafts() {
  try { return wx.getStorageSync('appeal_drafts') || {}; } catch (e) { return {}; }
}

function getEmergencyProgress(eventId) {
  try {
    const all = wx.getStorageSync('emergency_progress') || {};
    return all[eventId] || null;
  } catch (e) { return null; }
}

function saveEmergencyProgress(eventId, progress) {
  try {
    const all = wx.getStorageSync('emergency_progress') || {};
    all[eventId] = { ...progress, eventId, updatedAt: Date.now() };
    wx.setStorageSync('emergency_progress', all);
  } catch (e) {}
}

function clearEmergencyProgress(eventId) {
  try {
    const all = wx.getStorageSync('emergency_progress') || {};
    delete all[eventId];
    wx.setStorageSync('emergency_progress', all);
  } catch (e) {}
}

function getPendingTask() {
  const shift = getTodayShift();
  if (shift.startTime && !shift.endTime) {
    return { type: 'shift', title: '今日出车进行中', desc: `开始于 ${shift.startTime}`, url: '/pages/shift/shift' };
  }
  const drafts = getAppealDrafts();
  const latest = Object.keys(drafts).map(key => drafts[key]).filter(Boolean).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))[0];
  if (latest) return { type: 'appeal', title: latest.sceneName || '未完成申诉', desc: `已保存草稿 · 第 ${latest.step || 1} 步`, url: `/pages/detail/detail?id=${latest.sceneId}&draft=1` };
  try {
    const events = wx.getStorageSync('emergency_progress') || {};
    const event = Object.keys(events).map(key => events[key]).filter(item => item && !item.completed).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))[0];
    if (event) return { type: 'emergency', title: event.title || '未完成现场处理', desc: '现场处理进度已保存', url: `/pages/emergency/emergency?event=${event.eventId}` };
  } catch (e) {}
  return null;
}

function clearBusinessData() {
  ['daily_ledgers', 'daily_shifts'].forEach(key => wx.removeStorageSync(key));
}

function clearWorkingData() {
  ['appeal_drafts', 'emergency_progress'].forEach(key => wx.removeStorageSync(key));
}

function getVehicleProfile() {
  try { return wx.getStorageSync('vehicle_profile') || {}; } catch (e) { return {}; }
}

function saveVehicleProfile(profile) {
  wx.setStorageSync('vehicle_profile', { ...profile, updatedAt: Date.now() });
}

module.exports = {
  getFavorites, isFavorite, toggleFavorite,
  getHistory, addHistory, clearHistory,
  getPlatform, setPlatform,
  getEvidenceProgress, setEvidenceProgress,
  getAllCounts, getCount, incrementCount,
  dateKey, getLedger, getTodayLedger, saveTodayLedger,
  getTodayShift, saveTodayShift,
  getAllLedgers, getAllShifts,
  getAppealDraft, saveAppealDraft, removeAppealDraft, getAppealDrafts,
  getEmergencyProgress, saveEmergencyProgress, clearEmergencyProgress,
  getPendingTask, clearBusinessData, clearWorkingData,
  getVehicleProfile, saveVehicleProfile
};
