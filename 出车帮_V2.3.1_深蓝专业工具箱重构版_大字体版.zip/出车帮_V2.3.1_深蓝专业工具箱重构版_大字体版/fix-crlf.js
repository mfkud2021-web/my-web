const fs = require('fs');
const path = 'C:/Users/mfkud/Documents/New project/司机申诉助手/utils/templates.js';
let content = fs.readFileSync(path, 'utf8');

let idx = 1;
content = content.replace(/undefined\r\n    updated/g, () => {
  const num = String(idx).padStart(2, '0');
  idx++;
  return `icon: '/images/scene_${num}.svg',\r\n    updated`;
});

fs.writeFileSync(path, content);
console.log('Fixed');

const verify = fs.readFileSync(path, 'utf8');
const matches = verify.match(/icon:.*/g);
console.log(matches.slice(0, 12).join('\n'));
